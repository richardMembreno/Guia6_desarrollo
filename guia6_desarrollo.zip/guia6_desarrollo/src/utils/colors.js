export default{
  PRIMARY_COLOR: '#1181BF',
  BUTTON_COLOR:'#FFEF36',
}